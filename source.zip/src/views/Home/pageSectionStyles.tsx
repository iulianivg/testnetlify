export const HERO_TOP_BG = 'linear-gradient(139.73deg, #E6FDFF 0%, #F3EFFF 100%)'
export const HERO_BOTTOM_BG = 'linear-gradient(180deg, #FFFFFF 22%, #D7CAEC 100%)'
export const HERO_SVG_TOP =
  'linear-gradient(180deg, rgba(255, 255, 255, 0.48) 24.67%, rgba(255, 255, 255, 0.35) 67.34%, #FFFFFF 100%);'
export const HERO_SVG_BOTTOM = '#D8CBED'
