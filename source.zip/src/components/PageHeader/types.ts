import { BoxProps } from '@pancakeswap/uikit'

export interface PageHeaderProps extends BoxProps {
  background?: string
}
