# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.1.0 (2021-05-07)


### Features

* Add eslint package ([#7](https://github.com/pancakeswap/pancake-toolkit/tree/master/packages/eslint-config-pancake/issues/7)) ([0e0454e](https://github.com/pancakeswap/pancake-toolkit/tree/master/packages/eslint-config-pancake/commit/0e0454eb9a63e976934956dc5c66fbef2ce2017a))





## [1.0.1](https://github.com/pancakeswap/pancake-toolkit/tree/master/packages/eslint-config-pancake/compare/@pancakeswap-libs/eslint-config-pancake@1.0.1...@pancakeswap-libs/eslint-config-pancake@1.0.1) (2021-03-19)


### Features

* Add eslint package ([#7](https://github.com/pancakeswap/pancake-toolkit/tree/master/packages/eslint-config-pancake/issues/7)) ([0e0454e](https://github.com/pancakeswap/pancake-toolkit/tree/master/packages/eslint-config-pancake/commit/0e0454eb9a63e976934956dc5c66fbef2ce2017a))
